model_ = ''
version_ = ''
modelList = []
useMindPlus = True
